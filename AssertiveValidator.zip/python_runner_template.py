#!/usr/bin/env python3
# code_runner.py - child template for executing injected user code.
# The orchestrator will execute:
#    python code_runner.py /path/to/predefs.pickle
#
# Behavior:
#  - load predefs pickle BEFORE replacing builtins (trusted I/O)
#  - then set restricted builtins
#  - inject pre-imported trusted modules into globals
#  - inject predefs keys into globals
#  - exec injected user code (in module scope)
#  - call code_runner() and await if needed
#  - print single marker line "__PY_OUT__:<json>" with result or error

import sys
import pickle
import json
import traceback
import inspect
import asyncio
import builtins

_MARKER = "__PY_OUT__:"

def _emit(payload: dict):
    try:
        print(_MARKER + json.dumps(payload), flush=True)
    except Exception:
        print(_MARKER + repr(payload), flush=True)

def _safe_serialize(v):
    try:
        json.dumps(v)
        return v
    except Exception:
        try:
            if hasattr(v, "tolist"):
                return v.tolist()
        except Exception:
            pass
        return {"__repr__": repr(v)}

def _load_predefs_from_pickle(path):
    try:
        with open(path, "rb") as f:
            data = pickle.load(f)
        if not isinstance(data, dict):
            _emit({"ok": False, "error": "predefs_invalid", "traceback": "predefs pickle must contain a dict"})
            sys.exit(1)
        return data
    except Exception:
        _emit({"ok": False, "error": "predefs_load_failed", "traceback": traceback.format_exc()})
        sys.exit(1)

def _setup_restricted_builtins():
    _ALLOWED_BUILTINS = [
        "abs", "all", "any", "bool", "chr", "dict", "enumerate",
        "float", "int", "len", "list", "map", "max", "min",
        "range", "repr", "sorted", "str", "sum", "zip", "print",
        "isinstance", "issubclass"
    ]
    safe = {}
    for n in _ALLOWED_BUILTINS:
        if hasattr(builtins, n):
            safe[n] = getattr(builtins, n)
    def _blocked_import(*args, **kwargs):
        raise ImportError("Import not allowed")
    safe["__import__"] = _blocked_import
    # remove other dangerous builtins if present
    for _bad in ("open","eval","exec","compile","input","globals","locals","vars","dir","getattr","setattr","delattr","help"):
        safe.pop(_bad, None)
    return safe

def _inject_predefs_into_globals(predefs: dict):
    for k, v in predefs.items():
        # assume keys are valid identifiers (orchestrator should ensure this)
        globals()[k] = v

def _main(predefs_pickle_path: str = None):
    # 1) LOAD predefs (trusted I/O), before we modify builtins
    predefs = {}
    if predefs_pickle_path:
        predefs = _load_predefs_from_pickle(predefs_pickle_path)

    # 2) Pre-imported trusted modules (inject real module objects)
    import requests as requests
    import json as json_mod
    import bs4 as bs4
    import typing as typing_mod
    import regex as regex_mod
    import asyncio as asyncio_mod

    globals()["requests"] = requests
    globals()["json"] = json_mod
    globals()["bs4"] = bs4
    globals()["typing"] = typing_mod
    globals()["regex"] = regex_mod
    globals()["asyncio"] = asyncio_mod

    # 3) Now lock down builtins for user code
    safe_builtins = _setup_restricted_builtins()
    globals()["__builtins__"] = safe_builtins

    # 4) Inject predefs into globals
    _inject_predefs_into_globals(predefs)

    # === USER CODE (injected by orchestrator) ===
# <<USER_CODE>>
    # === END USER CODE ===

    # Runner: call code_runner()
    try:
        if "code_runner" not in globals() or not callable(globals()["code_runner"]):
            _emit({"ok": False, "error": "missing_code_runner", "traceback": "code_runner() not defined or not callable"})
            sys.exit(1)

        fn = globals()["code_runner"]
        try:
            res = fn()
        except Exception:
            _emit({"ok": False, "error": "call_failed", "traceback": traceback.format_exc()})
            sys.exit(1)

        # Await if awaitable
        try:
            if inspect.isawaitable(res):
                try:
                    res = asyncio.run(res)
                except Exception:
                    _emit({"ok": False, "error": "await_failed", "traceback": traceback.format_exc()})
                    sys.exit(1)
        except Exception:
            _emit({"ok": False, "error": "await_detection_failed", "traceback": traceback.format_exc()})
            sys.exit(1)

        if not isinstance(res, dict):
            _emit({"ok": False, "error": "invalid_return_type", "traceback": "code_runner() must return a dict", "value": _safe_serialize(res)})
            sys.exit(1)

        safe_res = {k: _safe_serialize(v) for k, v in res.items()}
        _emit({"ok": True, "result": safe_res})
        sys.exit(0)

    except SystemExit:
        raise
    except Exception:
        _emit({"ok": False, "error": "internal_failure", "traceback": traceback.format_exc()})
        sys.exit(2)

if __name__ == "__main__":
    predefs_path = sys.argv[1] if len(sys.argv) > 1 else None
    _main(predefs_path)
