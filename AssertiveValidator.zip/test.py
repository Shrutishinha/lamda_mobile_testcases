import unittest
import os, json, traceback
from appium import webdriver
from appium.options.ios import XCUITestOptions
try:
    from condition import Condition, ResolvedCondition, ConcatenationOperator
    from UIActions import get_variable_value
except Exception as e:
    pass
from UIActions import ui_action, lambda_hooks, query, vision_query, perform_assertion, string_to_float, execute_lambda_hooks, get_test_case_name, lambda_test_case_start, lambda_test_case_end, execute_api_action, set_operations_meta_data, reload_metadata_root, user_variables, initialize_network_throttle, access_value, get_test_status, SmartVariables, execute_script_action, inject_media, execute_deeplink

import argparse, requests
from requests.auth import HTTPBasicAuth
from utils import build_caps
import sys
from lambdatest_selenium_driver.smartui_app_snapshot import SmartUIAppSnapshot
smartui = SmartUIAppSnapshot()

username = os.getenv("LT_USERNAME")
access_key = os.getenv("LT_ACCESS_KEY")
hub_url = os.getenv("LT_HUB_URL", "mobile-hub.lambdatest.com")
metadata_url = "https://manual-api.lambdatest.com/app/"

# caps options
options = XCUITestOptions()

# driver settings
driver_settings = {}

def app_metadata(metaData_url, username, access_key, platform_name):
    try:
        response = requests.get(metaData_url, auth=HTTPBasicAuth(username, access_key))
        response.raise_for_status()  

        try:
            data = response.json().get("data", {})
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to decode JSON: {e}")

        if not data:
            raise KeyError("Missing 'data' in the response")

        os.environ["app"] = data.get("name", "unknown-app")

        metadata_str = data.get("metadata", "{}")
        try:
            metadata = json.loads(metadata_str)
        except json.JSONDecodeError:
            metadata = {}
            print("Warning: Failed to parse metadata. Defaulting version.")

        if platform_name.lower() == "android":
            os.environ["appVersion"] = metadata.get("versionName", "0.0.1")
        else:
            os.environ["appVersion"] = metadata.get("version", "0.0.1")

    except requests.RequestException as e:
        os.environ["app"] = "unknown-app"
        os.environ["appVersion"] = "0.0.1"
    except Exception as e:
        os.environ["app"] = "unknown-app"
        os.environ["appVersion"] = "0.0.1"

        
class FirstSampleTest(unittest.TestCase):
    driver = None

    def setUp(self):
        self.driver = webdriver.Remote(
            command_executor="https://{}:{}@{}/wd/hub".format(
                username, access_key, hub_url
            ),
            options=options,
        )
        # update driver settings if any
        if driver_settings and len(driver_settings) > 0:
            print(f"Updating driver settings: {driver_settings}")
            self.driver.update_settings(driver_settings)

    def test_demo_site(self):
        driver = self.driver
        status = "failed"
        smart = SmartVariables()
        
        try:    
            driver.implicitly_wait(10)
            reload_metadata_root()

            initialize_network_throttle(driver)

            # Click on the Toast button in the first row left
            lambda_hooks(driver, """Click on the Toast button in the first row left""")
            ui_action(driver = driver, operation_index = str(0))

            # Click on the Notification button in the middle right
            lambda_hooks(driver, """Click on the Notification button in the middle right""")
            ui_action(driver = driver, operation_index = str(1))

            # Click on the Toast button in the middle left
            lambda_hooks(driver, """Click on the Toast button in the middle left""")
            ui_action(driver = driver, operation_index = str(2))

            # Click on the VPN icon in the middle icon grid
            lambda_hooks(driver, """Click on the VPN icon in the middle icon grid""")
            ui_action(driver = driver, operation_index = str(3))

            # Click on the VPN icon with blue label in the middle icon grid
            lambda_hooks(driver, """Click on the VPN icon with blue label in the middle icon grid""")
            ui_action(driver = driver, operation_index = str(4))

            # Scroll down by 24%
            lambda_hooks(driver, """Scroll down by 24%""")
            ui_action(driver = driver, operation_index = str(5))

            # Scroll down by 24%
            lambda_hooks(driver, """Scroll down by 24%""")
            ui_action(driver = driver, operation_index = str(6))

            # Scroll down by 26%
            lambda_hooks(driver, """Scroll down by 26%""")
            ui_action(driver = driver, operation_index = str(7))

            # Click on the 'Read More' link below article summary
            lambda_hooks(driver, """Click on the 'Read More' link below article summary""")
            ui_action(driver = driver, operation_index = str(8))

            # Scroll down by 16%
            lambda_hooks(driver, """Scroll down by 16%""")
            ui_action(driver = driver, operation_index = str(9))

            # Click on the blue circular arrow button in the center
            lambda_hooks(driver, """Click on the blue circular arrow button in the center""")
            ui_action(driver = driver, operation_index = str(10))

            # Click on the 'Close' button in the top right corner of the ad banner
            lambda_hooks(driver, """Click on the 'Close' button in the top right corner of the ad banner""")
            ui_action(driver = driver, operation_index = str(11))

            # Scroll up by 1%
            lambda_hooks(driver, """Scroll up by 1%""")
            ui_action(driver = driver, operation_index = str(12))

            # Click on the Back button in the top left corner
            lambda_hooks(driver, """Click on the Back button in the top left corner""")
            ui_action(driver = driver, operation_index = str(13))

            # Click on the 'Text' button in the middle left section
            lambda_hooks(driver, """Click on the 'Text' button in the middle left section""")
            ui_action(driver = driver, operation_index = str(14))

            # Click on the GeoLocation button in the middle right section
            lambda_hooks(driver, """Click on the GeoLocation button in the middle right section""")
            ui_action(driver = driver, operation_index = str(15))

            # Click on the 'Back' button in the top left corner
            lambda_hooks(driver, """Click on the 'Back' button in the top left corner""")
            ui_action(driver = driver, operation_index = str(16))

            # Click on Speed Test button in bottom right group of buttons
            lambda_hooks(driver, """Click on Speed Test button in bottom right group of buttons""")
            ui_action(driver = driver, operation_index = str(17))

            # Click on the Continue button in the privacy policy popup
            lambda_hooks(driver, """Click on the Continue button in the privacy policy popup""")
            ui_action(driver = driver, operation_index = str(18))

            # Update the status to passed
            status = get_test_status()
        
        except Exception as e:
            print(f"An error occurred: {traceback.format_exc()}")
        
        finally:
            # Update the status at the end
            if driver is not None:
                driver.execute_script(f"lambda-status={status}")

    # tearDown runs after each test case
    def tearDown(self):
        if self.driver is not None:
            self.driver.quit()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Custom argument demo for unittest.")
    
    parser.add_argument("--test-config", type=str,
                        help="Test config file path")

    parser.add_argument("--test-instance-id", type=str,
                        help="Test Instance to be picked from the test config file")
    parser.add_argument("--operations-meta-data", type=str, default="operations_meta_data.json",
                        help="Operation meta data to be picked from the file")

    args, unittest_args = parser.parse_known_args()
    set_operations_meta_data(args.operations_meta_data)
    
    # set fixed caps and settings
    fixed_caps = {'tms.tc_id': 'TC-2', 'platformName': 'ios', 'autoAcceptAlerts': True, 'autoDismissAlerts': False, 'deviceOrientation': 'auto'}
    fixed_driver_settings = {'respectSystemAlerts': True}
    
    # fetch caps
    lt_options = build_caps(args.test_instance_id, args.test_config)
    
    # fetch and set driver settings
    driver_settings = lt_options.get("driver_settings", {})
    driver_settings.update(fixed_driver_settings) # override fixed driver settings
    
    # del driver settings from lt_options
    lt_options.pop("driver_settings", None)
    
    # override fixed caps
    lt_options.update(fixed_caps)
    
    os.environ["deviceName"] = lt_options.get("deviceName", "")
    os.environ["platformVersion"] = lt_options.get("platformVersion", "")
    os.environ["platformName"] = lt_options.get("platformName", "")

    metaData_url = metadata_url + lt_options.get("app").removeprefix("lt://") + "/metadata"
    app_metadata(metaData_url, username, access_key,lt_options.get("platformName"))

    # set final caps in options
    print(f"Test capabilities: {lt_options}")
    options.set_capability("LT:Options", lt_options)
    
    unittest.main(argv=[sys.argv[0]] + unittest_args)
