// node_runner_template.js
// Synchronous isolated-vm runner template (no fs).
// Notes:
// - Variables dict is decoded on the host (Node) then embedded as a JSON *string*
//   into the isolate, parsed there, and assigned onto the isolate global.
// - User code is decoded on the host, then passed into the isolate as a JS string,
//   executed via `new Function(...)` so a top-level `return ...` works.

'use strict';
const ivm = require('isolated-vm');

const MARKER = __MARKER__;
const MEMORY_LIMIT = __MEMORY_LIMIT__;

// Base64 payloads (already JSON-quoted during template substitution)
const USER_CODE_B64 = __USER_CODE_B64__;
const VARS_B64      = __VARS_B64__ || "";

// Decode on the host side (Buffer is NOT available inside the isolate)
let USER_CODE_STR = "";
let VARS_JSON_STR = "";
try { USER_CODE_STR = Buffer.from(USER_CODE_B64, 'base64').toString('utf8'); } catch (_){}
try { VARS_JSON_STR = Buffer.from(VARS_B64, 'base64').toString('utf8'); } catch (_){}

try {
  // Create isolate & context
  const isolate = new ivm.Isolate({ memoryLimit: MEMORY_LIMIT });
  const context = isolate.createContextSync();
  const jail = context.global;
  try { jail.setSync('global', jail.derefInto()); } catch (_) {}
  try { jail.setSync('_global', jail.derefInto()); } catch (_) {}

  // Build wrapper that:
  // 1) Parses VARS JSON and assigns each key to the isolate global,
  // 2) Executes user code via new Function(code),
  // 3) Returns a JSON string with the result or an error.
  const wrapped = `;(function(){
    try {
      // 1) Load variables dict and assign to global (non-strict: 'this' is global)
      const __VARS_JSON_STR__ = ${JSON.stringify(VARS_JSON_STR)};
      let __vars = {};
      try {
        __vars = __VARS_JSON_STR__ ? JSON.parse(__VARS_JSON_STR__) : {};
      } catch (_) { __vars = {}; }
      (function(o){
        if (o && typeof o === 'object') {
          for (const k of Object.keys(o)) {
            try { this[k] = o[k]; } catch(_) {}
          }
        }
      }).call(this, __vars);

      // 2) Execute user code
      const __CODE__ = ${JSON.stringify(USER_CODE_STR)};
      const __fn__ = new Function(__CODE__);
      const __ret = __fn__();

      // 3) Marshal result
      const __val = (typeof __ret === 'undefined') ? null : __ret;
      return JSON.stringify(
        { success: true, value: __val, error: null, line: null, timed_out: false, exit_code: 0 },
        (k, v) => (typeof v === 'bigint') ? v.toString() : v
      );
    } catch (e) {
      const stack = (e && (e.stack || e.message)) || String(e);
      let line = null;
      try { const m = (stack || '').match(/:(\\d+):\\d+/); if (m) line = parseInt(m[1], 10); } catch(_) {}
      return JSON.stringify({ success: false, value: null, error: stack, line, timed_out: false, exit_code: 2 });
    }
  })();`;

  // Compile
  let scriptObj;
  try {
    scriptObj = isolate.compileScriptSync(wrapped);
  } catch (compileErr) {
    const errMsg = (compileErr && (compileErr.stack || compileErr.message)) || String(compileErr);
    console.log(MARKER + JSON.stringify({ success: false, value: null, error: errMsg, line: null, timed_out: false, exit_code: 1 }));
    try { isolate.dispose(); } catch(_) {}
    process.exit(1);
  }

  // Run (returns the JSON string)
  try {
    const outStr = scriptObj.runSync(context);
    console.log(MARKER + (typeof outStr === 'string' ? outStr : String(outStr)));
    try { isolate.dispose(); } catch(_) {}
    process.exit(0);
  } catch (runErr) {
    const stack = (runErr && (runErr.stack || runErr.message)) || String(runErr);
    let line = null;
    try { const m = (stack || '').match(/:(\d+):\d+/); if (m) line = parseInt(m[1], 10); } catch(_) {}
    console.log(MARKER + JSON.stringify({ success: false, value: null, error: stack, line, timed_out: false, exit_code: 2 }));
    try { isolate.dispose(); } catch(_) {}
    process.exit(2);
  }

} catch (outer) {
  const msg = (outer && (outer.stack || outer.message)) || String(outer);
  console.log(MARKER + JSON.stringify({ success: false, value: null, error: msg, line: null, timed_out: false, exit_code: 3 }));
  process.exit(3);
}
